package jpa.dao;

import java.util.List;

import jpa.entitymodels.Course;

public interface CourseDao {

	public List<Course> getAllCourses();

}
